from django.apps import AppConfig


class CatsConfig(AppConfig):
    name = 'cats'
